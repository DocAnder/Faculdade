import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class sistemaAeroporto {
    BufferedReader leitor;
    private companhia aero1;    
    public static void main(String[] args) throws NumberFormatException, IOException {
        
        sistemaAeroporto systemAero = new sistemaAeroporto();
        systemAero.leitor = new BufferedReader(new InputStreamReader(System.in));

        systemAero.aero1 = new companhia();
        
        System.out.println("---==Sistema de Controle de Aeroportos==---");
        System.out.println("Informe a companhia responsavel pelos voos:");
        systemAero.aero1.setCia(systemAero.leitor.readLine());
        System.out.println("Informe o destino: ");
        systemAero.aero1.setDestino(systemAero.leitor.readLine());        
        systemAero.menu();
    }

    public void menu() throws NumberFormatException, IOException{
        int opcao = 0;
        do {
        System.out.println("");
        System.out.println("Escolha dentre as opcoes disponiveis: ");
        System.out.println("[1] - Cadastrar um novo Voo.");
        System.out.println("[2] - Listar Voos existentes.");
        System.out.println("[3] - Listar passageiros de TODOS os Voos.");
        System.out.println("[4] - Listar passageiros de UM voo.");
        System.out.println("[5] - Verificar assentos disponíveis de um Voo.");
        System.out.println("[6] - Sair.");
        //int opcao = entrada.readLine(); -> Não funcionou desta forma inicial porque o leitor do buffer estava interno na função MAIN. Para acesso global, movi o leitor para fora da main. 
        opcao = Integer.parseInt(this.leitor.readLine());//Desta forma, o leitor passou a ser global, permitando a leitura fora da main.
        if (opcao <= 0 || opcao > 6) {
            System.out.println("Opção invalida - Tente novamente.");
        } else {
            switch (opcao) {
                case 1:
                    cadastrarVoo();                
                    break;
                case 2:
                    listarVoos();
                    break;
                case 3:
                    listarTodosPassageiros();    
                    break;
                case 4:
                    int matricula, volta; 
                    System.out.println("Informe a matricula do voo: ");
                    matricula = Integer.parseInt(leitor.readLine());
                    //RECEBER O RETORNO DA FUNÇÃO E VERIFICAR SE É 0 OU 1 
                    volta = listarPassageiros(matricula);
                    if (volta == 0){
                        System.out.println("Voo inexistente - Tente novamente!.");
                    }
                    break;
                case 5:
                    int matricula2, volta2; 
                    System.out.println("Informe a matricula do voo: ");
                    matricula2 = Integer.parseInt(leitor.readLine());
                    volta2 = listarPassageiros(matricula2);
                    if(volta2 == 0){
                        System.out.println("Voo inexistente - Tente novamente!");
                    }
                    else{
                        System.out.println("---==Passageiros cadastrados nesse voo==---");                                        
                        System.out.println("Considerando a tripulação e passageiros já cadastrados....");
                        System.out.println("Assentos ainda disponíveis: " + verificarAssentos(matricula2));
                    }
                    
                    break;
                default:
                    break;
            }    
        }        
        } while (opcao != 6);        
    }

    public void cadastrarVoo() throws IOException{        
        aero1.setVetAviao(dadosAviao());//Chama a função que retorna um dado do tipo AVIAO com todos os dados preenchidos.
    }

    public aviao dadosAviao() throws NumberFormatException, IOException{       
        aviao x = new aviao();
        System.out.println("Informe a matricula do aviao: ");
        x.setMatricula(Integer.parseInt(leitor.readLine()));
        //System.out.println("Informe o numero de assentos: ");
        //x.setNumeroAssentos(Integer.parseInt(leitor.readLine()));
        System.out.println("Informe o numero de  tripulantes: ");
        x.setTripulacao(Integer.parseInt(leitor.readLine()));
        int resp;
        System.out.println("Obrigatorio cadastrar ao menos um passageiro para esse voo.");
        do {
            x.setVetorPassageiros(dadosPassageiro());
            System.out.println("Cadastrar outro passageiro?");
            System.out.println("[1] Continuar | [0] Sair.");
            resp = Integer.parseInt(leitor.readLine());    
        } while (resp != 0);       
        return x;
    }
    //ALTERAR PARA UM LOOP O CADASTRO SOMENTE DOS PASSAGEIROS. PROVALMENTE, O LOOP DEVE OCORRER NA LINHA 61, QUANDO A FUNÇÃO É CHAMADA, PARA ALTERAR A POSIÇÃO  NO VETOR DE PASSAGEIROS ANTES DE CADASTRAR O PROXIMO.
    public passageiro dadosPassageiro() throws NumberFormatException, IOException{
        passageiro x = new passageiro();
        System.out.println("---==CADASTRO DE PASSAGEIRO==---");
        System.out.println("Informe o nome do passageiro: ");
        x.setNome(leitor.readLine());
        System.out.println("Informe o CPF do passageiro: ");        
        x.setCpf(Integer.parseInt(leitor.readLine()));
        System.out.println("Informe a idade: ");
        x.setIdade(Integer.parseInt(leitor.readLine()));
        return x;
    }
    
    public void listarVoos(){
        int i = 0;
        if(i == aero1.getQtdAvioes()){
            System.out.println("Nenhum voo cadastro ainda!");
        }else{
            System.out.println("   ---==LISTAGEM DOS VOOS==---");
            for (; i < aero1.getQtdAvioes(); i++) {                
                System.out.print("MATRICULA: ");
                System.out.print(aero1.getVetAviao(i).getMatricula());
                //System.out.print("  ASSENTOS: ");
                //System.out.print(aero1.getVetAviao(i).getNumeroAssentos());
                System.out.print("  TRIPULANTES: ");
                System.out.print(aero1.getVetAviao(i).getTripulacao());
                System.out.print(" PASSAGEIROS: ");
                System.out.println(aero1.getVetAviao(i).getQtdPassageiros());
            }
        }         
    }

    public void listarTodosPassageiros(){
        for(int i = 0; i < aero1.getQtdAvioes(); i++){
            aviao x = aero1.getVetAviao(i);
            System.out.println("---==PASSAGEIROS VOO MATRICULA " + aero1.getVetAviao(i).getMatricula() + "==---");
            for (int j = 0; j < x.getQtdPassageiros(); j++) {
                System.out.print("Nome: ");
                System.out.print(x.getVetorPassageiros(j).getNome());
                System.out.print(" Idade: ");
                System.out.print(x.getVetorPassageiros(j).getIdade());  
                System.out.print(" CPF: ");              
                System.out.println(x.getVetorPassageiros(j).getCpf());    
            }
        }
    }

    //ALTER PARA RETORNAR 0 CASO O CODIGO DO VOO NÃO SEJA ENCONTRADO NO VETOR OU 1 CASO SEJA.
    public int listarPassageiros(int x){ 
        int achou = 0;       
        for (int i = 0; i < aero1.getQtdAvioes(); i++) {
            aviao y = aero1.getVetAviao(i);
            if (x == y.getMatricula()) {
                achou = 1;//se entrou é pq achou
                for (int j = 0; j < y.getQtdPassageiros(); j++) {
                    System.out.print("Nome: ");
                    System.out.print(y.getVetorPassageiros(j).getNome());
                    System.out.print(" Idade: ");
                    System.out.print(y.getVetorPassageiros(j).getIdade());  
                    System.out.print(" CPF: ");              
                    System.out.println(y.getVetorPassageiros(j).getCpf());    
                }
            break;            
            }            
        }
        return achou;//Começa valendo 0 e retorna 1 se achar a matricula.
    }

    public int verificarAssentos(int x){
        int aux = 0;
        for (int i = 0; i < aero1.getQtdAvioes(); i++) {
            aviao y = aero1.getVetAviao(i);
            if (x == y.getMatricula()) {
                aux = y.getAssentosLivres();
                break;                
            }            
        }
        return aux;
    }




}

