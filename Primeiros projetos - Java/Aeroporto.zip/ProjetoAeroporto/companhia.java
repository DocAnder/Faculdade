public class companhia {
    
    private String cia;
    private String destino;    
    private aviao [] vetAviao;
    private int qtdAvioes;
    
    public companhia(){
        this.vetAviao = new aviao[10];
        this.qtdAvioes = 0;
    }

    public String getCia() {
        return cia;
    }

    public void setCia(String cia) {
        this.cia = cia;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }    

    public aviao getVetAviao(int x) {
        return vetAviao[x];
    }

    public void setVetAviao(aviao x) {//Recebe um dado do tipo avião para guardar no vetor. Ao chamar a função, lembrar de criar um objeto do tipo avião para enviar.
        if (this.qtdAvioes == 10) {
            System.out.println("Limite maximo de voos atingido!");
        } else {
            this.vetAviao [this.qtdAvioes] = x;
            this.qtdAvioes++;            
        }
    }

    public int getQtdAvioes() {
        return qtdAvioes;
    }

    public void setQtdAvioes(int qtdAvioes) {
        this.qtdAvioes = qtdAvioes;
    }

    

}
