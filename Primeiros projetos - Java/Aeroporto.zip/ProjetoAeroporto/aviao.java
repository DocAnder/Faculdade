public class aviao {
    
    private Integer matricula;
    //private Integer numeroAssentos = 40;
    private Integer tripulacao;
    private passageiro [] vetorPassageiros;
    private Integer qtdPassageiros;


    public aviao(){        
        this.vetorPassageiros = new passageiro[40];
        this.qtdPassageiros = 0;
    }

    public Integer getMatricula() {
        return matricula;
    }

    public void setMatricula(Integer matricula) {
        this.matricula = matricula;
    }    

    //public Integer getNumeroAssentos() {
    //    return numeroAssentos - (qtdPassageiros + tripulacao);
    //}

    //public void setNumeroAssentos(Integer numeroAssentos) {
    //    this.numeroAssentos = numeroAssentos;
    //}


    public Integer getTripulacao() {
        return tripulacao;
    }


    public void setTripulacao(Integer tripulacao) {
        this.tripulacao = tripulacao;
    }

    public passageiro getVetorPassageiros(int x) {//Alterar para imprimir conforme o numero de passageiros inseridos        
        return this.vetorPassageiros[x];        
    }

    public int getAssentosLivres(){ //Pega o tamanho do vetor e desconta o numero de tripulantes + passageiros já cadastrados.
        int x = vetorPassageiros.length - (this.qtdPassageiros + this.tripulacao);
        return x;
    }

    public void setVetorPassageiros(passageiro x) {//Alterar também para salvar na proxima posição        
        if (this.qtdPassageiros == 40) {
            System.out.println("Capacidade maxima de passageiros atingida!");
        } else {
            this.vetorPassageiros[qtdPassageiros] = x;
           this.qtdPassageiros++;    
        }        
    }

    public Integer getQtdPassageiros() {
        return qtdPassageiros;
    }


   

    






}
