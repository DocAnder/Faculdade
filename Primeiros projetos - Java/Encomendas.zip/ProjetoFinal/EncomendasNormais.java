
public class EncomendasNormais {
    
    private int numeroPedido;
    private String dataPostagem;
    private Float peso;

    public EncomendasNormais(int numeroPedido, String dataPostagem, Float peso){
        this.numeroPedido = numeroPedido;
        this.dataPostagem = dataPostagem;
        this.peso = peso;
    }
    
    public int getNumeroPedido() {
        return numeroPedido;
    }

    public void setNumeroPedido(int numeroPedido) {
        this.numeroPedido = numeroPedido;
    }

    public String getDataPostagem() {
        return dataPostagem;
    }

    public void setDataPostagem(String dataPostagem) {
        this.dataPostagem = dataPostagem;
    }

    public Float getPeso() {
        return peso;
    }

    public void setPeso(Float peso) {
        this.peso = peso;
    }

    public float calcularValorFrete(Float kilo){
        //multiplica o peso pelo preço por KG.
        Float valor = this.peso * kilo;
        return valor;
    }
}
