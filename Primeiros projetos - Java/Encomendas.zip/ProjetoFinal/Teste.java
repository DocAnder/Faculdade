import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Teste {
    

    public static void main(String[] args) throws NumberFormatException, IOException {
        
        /*
        Transportadora t1 = new Transportadora();        
        t1.carregarConfiguracoes("arqConfig.csv");
        t1.importarDados("encomendas_foz.csv");
        //Nro pedido, Peso, Valor do Frete
        System.out.println("Numero pedido - Peso - Valor do Frete");
        //t1.getEncoNormais();
        t1.getEncoExpressas();

        /*MENU
         * -Importar arquivo de encomendas
           -Exibir a lista de encomendas Normais
           -Exibir a lista de encomendas Expressas
         */

        BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
        Transportadora t1 = new Transportadora();        

        //Tratamento da caputa do nome do arq. de configuração p/ impedir entradas vazias.        
        try {
            String nome = "";
            do {
                System.out.println("");
                System.out.println("Informe o nome do arquivo de configuracao: ");
                nome = teclado.readLine();                
                int flag2 = t1.carregarConfiguracoes(nome);
                if (flag2 == 0) {
                    nome = "";
                }    
            } while (nome.equalsIgnoreCase(""));

            /* 
            System.out.println("Informe o nome do arquivo de configuracao: ");
            nome = teclado.readLine();            
            while (nome.equals("")) {
                System.out.println("Obrigatorio informar o arquivo de configuracao para continuar.");
                System.out.println("Informe o nome do arquivo de configuracao: ");
                nome = teclado.readLine();
                int flag2 = t1.carregarConfiguracoes(nome);                
            }//Implementar um novo filtro para evitar o inicio do sistema quando um arquivo que não existe!
            */
            
            
        } catch (IOException e) {
            System.out.println("Erro na entrada de dados. Reinicie o sistema!");
        }
        
        //Menu com as opcoes
        int opcao = 5;        
        do {
            System.out.println(" ");
            System.out.println("-----===Selecione conforme opções===-----");
            System.out.println("[1] - Importar arquivo de encomendas");
            System.out.println("[2] - Exibir a lista de encomentas NORMAIS.");
            System.out.println("[3] - Exibir a lista de encomendas EXPRESSAS.");
            System.out.println("[0] - SAIR.");
            opcao = Integer.parseInt(teclado.readLine());

            switch (opcao) {
                case 1:                    
                    try {
                        System.out.println("Informe o nome do arquivo de encomendas: ");
                        String nomeArq = teclado.readLine();
                        t1.importarDados(nomeArq);
                    } catch (IOException e) {
                        System.out.println("Erro na entrada e dados. Reinicie o sistema!");
                    }                    
                    break;
                case 2:
                    System.out.println("Numero pedido - Peso - Valor do Frete");
                    t1.getEncoNormais();
                    break;
                case 3:
                    System.out.println("Numero pedido - Peso - Valor do Frete");
                    t1.getEncoExpressas();
                    break;            
                default:
                    System.out.println("Opcao invalida!");
                    break;
            }
        } while (opcao != 0);

        teclado.close();
        

    }
}
