import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Transportadora implements ImportacaoArquivos {

    private EncomendasExpressas [] EncoExpressas; 
    private EncomendasNormais [] EncoNormais;    
    private Float precoKiloNormal;
    private int ContadorNormais;
    private Float precoKiloExpressa;
    private int ContadorExpressas;

    

    public int getContadorNormais() {
        return ContadorNormais;
    }

    public void setContadorNormais(int contadorNormais) {
        ContadorNormais = contadorNormais;
    }

    public int getContadorExpressas() {
        return ContadorExpressas;
    }

    public void setContadorExpressas(int contadorExpressas) {
        ContadorExpressas = contadorExpressas;
    }

    public Transportadora(){
        this.EncoExpressas = new EncomendasExpressas[1000];
        this.EncoNormais = new EncomendasNormais[1000];
        this.ContadorExpressas = 0;
        this.ContadorNormais = 0;
    }

    public void getEncoExpressas() {
        for (int i = 0; i < ContadorExpressas; i++) {
            System.out.println("    " +
            this.EncoExpressas[i].getNumeroPedido() + "         " +
            this.EncoExpressas[i].getPeso() + "     " +
            this.EncoExpressas[i].calcularValorFrete(precoKiloExpressa)
            );
        }
    }

    public void setEncoExpressas(EncomendasExpressas novaEncomenda) {
        if (this.ContadorExpressas < EncoExpressas.length) {
            this.EncoExpressas[ContadorExpressas] = novaEncomenda;
            this.ContadorExpressas++;
        }
    }

    public void getEncoNormais() {
        for (int i = 0; i < ContadorNormais; i++) {
            System.out.println( "     " + 
                //Nro pedido, Peso, Valor do Frete
                this.EncoNormais[i].getNumeroPedido() + "       " +
                this.EncoNormais[i].getPeso() + "       " +
                this.EncoNormais[i].calcularValorFrete(precoKiloNormal)
            );
            
        }
    }

    public void setEncoNormais(EncomendasNormais novaEncomenda) {
        if (this.ContadorNormais < EncoNormais.length) {
            this.EncoNormais[ContadorNormais] = novaEncomenda;
            this.ContadorNormais++;
        }
    }

    public Float getPrecoKiloNormal() {
        return precoKiloNormal;
    }

    public void setPrecoKiloNormal(Float precoKiloNormal) {
        this.precoKiloNormal = precoKiloNormal;
    }

    public Float getPrecoKiloExpressa() {
        return precoKiloExpressa;
    }

    public void setPrecoKiloExpressa(Float precoKiloExpressa) {
        this.precoKiloExpressa = precoKiloExpressa;
    }

    
    @Override
    public int carregarConfiguracoes(String arqConfig) {
        int flag = 1;
        String arqFonte = arqConfig;        
        try {
            BufferedReader leitura = new BufferedReader(new FileReader(arqFonte));
            
            try {
                String linha;
                while ((linha = leitura.readLine()) != null) {
                    String [] LinhaDoArquivo = linha.split(";");
                    if (LinhaDoArquivo[0].equals("Normal")) {
                        setPrecoKiloNormal(Float.parseFloat(LinhaDoArquivo[2]));
                    }
                    if (LinhaDoArquivo[0].equals("Expressa")) {
                        setPrecoKiloExpressa(Float.parseFloat(LinhaDoArquivo[2]));
                    }                
                }
                leitura.close();
                System.out.println("Configurações de valor de frete carregadas!");                
            } catch (IOException e) {
                System.out.println("Não foi possivel ler o arquivo. Possível arquivo corrompido!");
            }              
        } catch (FileNotFoundException e) {
                if (arqFonte.isEmpty()) {
                    System.out.println("Obrigatório informar o nome do arquivo de configuracao para uso do sistema!");
                }else{
                    System.out.println("Arquivo não encontrado ou nome incorreto!");
                }            
                
                flag = 0;                        
        }     
        return flag;
        
    }

    @Override
    public void importarDados(String arqDadosEntrada) {
        String arqFonte = arqDadosEntrada;
        try {
            BufferedReader leitura = new BufferedReader(new FileReader(arqFonte));
            
            try {
                String linha;
                while ((linha = leitura.readLine()) != null) {
                    String [] LinhaDoArquivo = linha.split(";");
                    if (LinhaDoArquivo[2].equals("EN")) {
                        // numPedido[0] - DataPostagem[1] - peso[4]
                        EncomendasNormais novaEnco = new EncomendasNormais
                        (
                            Integer.parseInt(LinhaDoArquivo[0]),
                            LinhaDoArquivo[1],
                            Float.parseFloat(LinhaDoArquivo[4])
                        );
                        setEncoNormais(novaEnco);
                    } // numPedido[0] - DataPostagem[1] - peso[4] - prazo entrega[3] - contatoRecebedor[5]
                    if (LinhaDoArquivo[2].equals("EE")) {
                        EncomendasExpressas novaEnco2 = new EncomendasExpressas
                        (
                            Integer.parseInt(LinhaDoArquivo[0]),
                            LinhaDoArquivo[1],
                            Float.parseFloat(LinhaDoArquivo[4]),
                            Integer.parseInt(LinhaDoArquivo[3]),
                            LinhaDoArquivo[5]
                        );
                        setEncoExpressas(novaEnco2);
                    }
                }
                System.out.println("Encomendas carregadas com sucesso!");
                leitura.close();           
            } catch (IOException e) {
                System.out.println("Não foi possivel ler o arquivo. Possível arquivo corrompido!");
            }
                
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo não encontrado ou nome incorreto!");
        }
        
    }


    



}
