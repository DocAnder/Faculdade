public interface ImportacaoArquivos{

    public int carregarConfiguracoes(String arqConfig);
    public void importarDados(String arqDadosEntrada);

  
}