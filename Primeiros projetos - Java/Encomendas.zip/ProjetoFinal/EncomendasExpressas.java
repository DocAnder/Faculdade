public class EncomendasExpressas extends EncomendasNormais {
    
    int prazoEntrega;
    String contatoRecebedor;

    public EncomendasExpressas(int numeroPedido, String dataPostagem, Float peso, int prazoEntrega, String contatoRecebedor) {
        super(numeroPedido, dataPostagem, peso);
        this.prazoEntrega = prazoEntrega;
        this.contatoRecebedor = contatoRecebedor;
    }
  
    public int getPrazoEntrega() {
        return prazoEntrega;
    }

    public void setPrazoEntrega(int prazoEntrega) {
        this.prazoEntrega = prazoEntrega;
    }

    public String getContatoRecebedor() {
        return contatoRecebedor;
    }

    public void setContatoRecebedor(String contatoRecebedor) {
        this.contatoRecebedor = contatoRecebedor;
    }

    @Override
    public float calcularValorFrete(Float valor){
        Float preco = 0f;
        //prazo de entrega seja 3 dias ou mais, multiplica peso pelo preço por KG
        if (this.prazoEntrega >= 3) {
            preco = this.getPeso() * valor;
        }
        //prazo de entrega seja até 2 dias, multiplica peso pelo preço por KG, e acrescenta 25%
        if (this.prazoEntrega <= 2) {
            preco = this.getPeso() * valor;
            Float taxa = preco * 0.25f;
            preco = preco + taxa;
        }
        return preco;
    }
        
}
